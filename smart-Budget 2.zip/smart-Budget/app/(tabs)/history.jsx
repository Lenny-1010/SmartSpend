import { View, Text } from 'react-native'
import React from 'react'

export default function History() {
  return (
    <View>
      <Text>History</Text>
    </View>
  )
}