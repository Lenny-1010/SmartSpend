import { KindeSDK } from '@kinde-oss/react-native-sdk-0-7x';

export const client = new KindeSDK(
    'https://bmvceo.kinde.com', 
    'exp://10.199.105.177:8081', 
    'c4901f8a887945169f7bec683c8d1171', 
    'exp://10.199.105.177:8081');
